package data.service;

import data.dto.MemberDto;
import data.mapper.MemberMapperInter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

@Service
public class MemberService {

    @Autowired
    private MemberMapperInter memberInter;

    public int getTotalCount(){
        return memberInter.getTotalCount();
    }

    public int getIdCheckCount(String searchid){

        return memberInter.getIdCheckCount(searchid);
    }
    public void insertMember(MemberDto dto){
        memberInter.insertMember(dto);
    }
    public List<MemberDto> getAllMembers(){
        return memberInter.getAllMembers();
    }
    public MemberDto getData(int num){

        return memberInter.getData(num);
    }
    public MemberDto getDataById(String myid){
        return memberInter.getDataById(myid);
    }
    public void updatePhoto(int num,String photo){
        Map<String, Object> map = new HashMap<>();
        map.put("num",num);
        map.put("photo",photo);
        memberInter.updatePhoto(map);
    }
    public void updateMember(MemberDto dto){
        memberInter.updateMember(dto);
    }

    public boolean isEqualPassCheck(int num,String passwd){
        Map<String, Object> map = new HashMap<>();
        map.put("num",num);
        map.put("passwd",passwd);

        return memberInter.equalPassCheck(map);
    }
    public void deleteMember(int num){
        memberInter.deleteMember(num);
    }

    public boolean isLoginCheck(String myid,String pass){
        return memberInter.isLoginCheck(myid,pass)==1?true:false;
    }



}
